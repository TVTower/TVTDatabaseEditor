Nach dem ersten Öffnen das Datenbankprojekt aktualisieren:
* Im Project Explorer das Kontextmenü für TVTower-Database öffnen und "Clean" wählen (F5)

Dokumentation Datenbankformat: https://github.com/TVTower/Documentation/blob/master/database_de/main.md

Dokumentation Editor:
https://github.com/TVTower/Documentation/blob/master/database_editor/xtext_de/main.md



Refresh the database project after opening it the first time
* Open the context menu of TVTower-Database in the project explorer and select "Clean" (F5)

Documentation Database format:
https://github.com/TVTower/Documentation/blob/master/database_de/main.md

Documentation Editor:
https://github.com/TVTower/Documentation/blob/master/database_editor/xtext_en/main.md
